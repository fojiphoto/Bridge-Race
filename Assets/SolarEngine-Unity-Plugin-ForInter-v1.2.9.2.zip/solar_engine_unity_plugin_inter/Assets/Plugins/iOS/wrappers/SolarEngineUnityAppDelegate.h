//
//  SolarEngineUnityAppDelegate.h
//  UnityFramework
//
//  Created by baixin.pan on 2024/7/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SolarEngineUnityAppDelegate : NSObject

@end

NS_ASSUME_NONNULL_END
